from aiogram import Bot

TOKEN = "5478037139:AAGEMwmj5IjclMzr0IRbbt79bq8zrzwm-0E"
PARSE_MODE = "HTML"

bot = Bot(token = TOKEN, parse_mode=PARSE_MODE)